local comp = computer

function comp.runlevel()
	return "1"
end

return comp 
