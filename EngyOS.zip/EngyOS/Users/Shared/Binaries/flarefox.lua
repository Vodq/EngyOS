-- Shortcut to A:/Users/Shared/Binaries/Flarefox/flarefox.lua
dofile("A:/Users/Shared/Binaries/Flarefox/flarefox.lua")
