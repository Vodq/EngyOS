print("Use cd [path] (where [path] is the directory) to go at a directory you want to go to")
print("Type dir to list the files and directories in your the directory.")
print("Type the name of the program you want to use (ends with .lua)")
