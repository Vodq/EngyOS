return {
	buffer = {
		readBufferSize = 2048,
		defaultWriteBufferSize = 2048,
		maxWriteBufferSize = 64*1024
	}
}
-- TODO: load from/save to file
