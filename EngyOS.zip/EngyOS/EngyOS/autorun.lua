local env = os.getenvs()
env["PATH"] = "A:/EngyOS/Binaries/;A:/Users/Shared/;A:/Users/Shared/Binaries"
env["PATHEXT"] = ".lua"
env["LIB_PATH"] = "A:/EngyOS/Libraries/?.lua;A:/EngyOS/Libraries/?.min.lua;A:/Users/Shared/Libraries/?.lua;A:/Users/Shared/Libraries/?.min.lua;./?.lua;./?.min.lua;A:/?.lua"
env["DRV_PATH"] = "A:/EngyOS/Drivers/"
env["PS1"] = "\x1b[107m\x1b[30m$USER# $PWD\x1b[40m\x1b[97m > "
env["USER"] = "guest"
